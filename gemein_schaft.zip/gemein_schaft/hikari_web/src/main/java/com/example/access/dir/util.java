package com.example.access.dir;

public class util {
    private String somme;
   
   

    public util() {
    }

    public util(String somme) {
        this.somme = somme;
       

    }

  //  @Override
    //public String toString() {
   //     return String.format(
   //         "[%d, %s]",
   //         key, value);
   // }


public String enSomme(){
return somme;
}
public void sommer(String somme){
this.somme = somme;
}
//public
}



