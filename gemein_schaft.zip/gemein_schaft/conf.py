BATCH_SIZE = 500
TOMATO_BEST_MOVIES = 'https://editorial.rottentomatoes.com/guide/best-netflix-movies-to-watch-right-now/'
OMDB_API_URL = 'http://www.omdbapi.com/?t='