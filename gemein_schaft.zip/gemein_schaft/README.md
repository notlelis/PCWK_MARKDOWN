# gemein_schaft
