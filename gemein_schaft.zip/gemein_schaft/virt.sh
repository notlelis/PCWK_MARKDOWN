echo '/root/.virtualenvs/vE/bin/activate'
